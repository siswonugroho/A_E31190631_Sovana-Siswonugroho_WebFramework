<?php
class No4_model extends CI_Model {
  public $nim = 'E31190631';
  public $nama = 'Sovana Siswonugroho';
  public $jurusan = 'TI';
  public $prodi = 'MIF';
  public $kotaAsal = 'Magetan';
}