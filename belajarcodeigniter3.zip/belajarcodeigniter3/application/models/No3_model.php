<?php
class No3_model extends CI_Model {
  public $txt = 'Hello World dari CI Model';
}