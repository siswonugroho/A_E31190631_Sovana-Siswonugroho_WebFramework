<?php
class Hello_model extends CI_Model {
  public $txt = 'Hello world';
}