<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Hello World</title>
</head>
<body>
  <table border="0">
    <tr>
      <td>NIM</td>
      <td>:</td>
      <td><?= $nim ?></td>
    </tr>
    <tr>
      <td>Nama</td>
      <td>:</td>
      <td><?= $nama ?></td>
    </tr>
    <tr>
      <td>Jurusan</td>
      <td>:</td>
      <td><?= $jurusan ?></td>
    </tr>
    <tr>
      <td>Prodi</td>
      <td>:</td>
      <td><?= $prodi ?></td>
    </tr>
    <tr>
      <td>Kota asal</td>
      <td>:</td>
      <td><?= $kotaAsal ?></td>
    </tr>
  </table>
</body>
</html>