<html>
  <head>
    <title>Hello CI</title>
  </head>
  <body>
    <h2><?= $teks; ?></h2>
    <h3>Menggunakan controller dan view</h3>
  </body>
</html>